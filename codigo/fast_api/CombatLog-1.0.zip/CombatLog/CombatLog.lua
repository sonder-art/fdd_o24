local debug = false;
local m_expandedCombatlogInstances :table = {};	-- Combatlog instances on the expanded panel	
local g_combatLogPanel;
local g_combatLogPanelBG;
local g_combatLogExpandButton;
local g_combatLogCloseButton;


function OnStatusMessage( str:string, fDisplayTime:number, type:number )
	-- Add the status messages to their own tab
	if ( type == nil or type ~= ReportingStatusTypes.DEFAULT ) then
		return false;
	end


	local format = UserConfiguration.GetClockFormat();
	local strTime, strMsg;
	
	if ( format == 1 ) then
		strTime = os.date("%H:%M:%S");
	else
		strTime = os.date("%#I:%M:%S %p");
	end

	-- NeutralCS
	strMsg = "[COLOR:Civ6Yellow][" .. strTime .. "] [COLOR:White]".. str;
	
	if debug then print("strMsg:  ", strMsg); end

	-- Add the combat log entry
	AddCombatlogEntry( strMsg, ContextPtr:LookUpControl("ExpandedCombatlogEntryStack"), m_expandedCombatlogInstances, ContextPtr:LookUpControl("ExpandedCombatlogLogPanel"));
end


function AddCombatlogEntry( combatlogString :string, combatlogEntryStack :table, combatlogInstances :table, combatlogLogPanel :table )
	if debug then print("AddCombatlogEntry"); end

	local controlTable = {};
	ContextPtr:BuildInstanceForControl( "CombatlogEntry", controlTable, combatlogEntryStack );
	    
	local newCombatlogEntry = { CombatlogControl = controlTable; };
	table.insert( combatlogInstances, newCombatlogEntry );

	local numCombatlogInstances:number = table.count(combatlogInstances);

	-- Limit combat log
	if ( numCombatlogInstances > 100 ) then
		combatlogEntryStack:ReleaseChild( combatlogInstances[ 1 ].CombatlogControl.CombatlogRoot );
		table.remove( combatlogInstances, 1 );
	end
	    
	controlTable.CombatlogString:SetText(combatlogString);
	controlTable.CombatlogRoot:SetSize(controlTable.CombatlogString:GetSize());	

	combatlogEntryStack:CalculateSize();
	combatlogEntryStack:ReprocessAnchoring();
	combatlogLogPanel:CalculateInternalSize();
	combatlogLogPanel:ReprocessAnchoring();
end


function OnLoadScreenClose()
	g_combatLogPanel   = ContextPtr:LookUpControl("ExpandedCombatlogPanel");
	g_combatLogPanelBG = ContextPtr:LookUpControl("ExpandedCombatlogPanelBG");

	-- Attach the UI element to the top panel, so that popups and side panels are shown above it
	local topPanel = ContextPtr:LookUpControl("/InGame/TopPanel");
	if ( topPanel ) then
		g_combatLogPanelBG:ChangeParent(topPanel);
		g_combatLogPanel:ChangeParent(topPanel);
	end

	-- Attach the expand & close button to the minimap
	local miniMap = ContextPtr:LookUpControl("/InGame/MinimapPanel/MinimapImage");
	g_combatLogExpandButton = ContextPtr:LookUpControl("CombatlogExpandButton")
	g_combatLogCloseButton  = ContextPtr:LookUpControl("CombatlogCloseButton")

	if ( miniMap ) then
		g_combatLogExpandButton:SetAnchor("R,T");
		g_combatLogExpandButton:SetOffsetVal(46,3);
		g_combatLogExpandButton:ChangeParent(miniMap);

		g_combatLogCloseButton:SetAnchor("R,T");
		g_combatLogCloseButton:SetOffsetVal(46,3);
		g_combatLogCloseButton:ChangeParent(miniMap);		

		miniMap:ReprocessAnchoring();

		g_combatLogExpandButton:RegisterCallback(Mouse.eLClick, OnOpenCombatLog);
		g_combatLogCloseButton:RegisterCallback(Mouse.eLClick, OnCloseCombatLog);

		-- The close button on the panel itself
		ContextPtr:LookUpControl("PanelCombatlogCloseButton"):RegisterCallback(Mouse.eLClick, OnCloseCombatLog);
	end
end


-- Open the Combat Log
function OnOpenCombatLog()		
    UI.PlaySound("Tech_Tray_Slide_Open");
	g_isVisible = true;
	g_combatLogPanel:SetHide(false);
	g_combatLogPanelBG:SetHide(false);
	g_combatLogExpandButton:SetHide(true);
	g_combatLogCloseButton:SetHide(false);
end


-- Close the Combat Log
function OnCloseCombatLog()
    UI.PlaySound("Tech_Tray_Slide_Closed");
	g_isVisible = false;
	g_combatLogPanel:SetHide(true);
	g_combatLogPanelBG:SetHide(true);
	g_combatLogExpandButton:SetHide(false);
	g_combatLogCloseButton:SetHide(true);
end



function Initialize()
	-- Observe the messages
	Events.StatusMessage.Add( OnStatusMessage );

	-- Re-attach the UI elements
	Events.LoadScreenClose.Add( OnLoadScreenClose );


	if ( debug ) then
		for i=1,20,1 do
			local strTime, strMsg;
			strTime = os.date("%H:%M:%S");
			strMsg  = "[COLOR:Civ6Yellow]\[" .. strTime .. "\] [COLOR:White]".. "Line " .. i .. " - This is some debugging line xxx aaa zzz e 1 2 3 2 1 2 4 1 4 5555 777 88 1";
			AddCombatlogEntry( strMsg, ContextPtr:LookUpControl("ExpandedCombatlogEntryStack"), m_expandedCombatlogInstances, ContextPtr:LookUpControl("ExpandedCombatlogLogPanel"));
		end
	end	

end


Initialize();